---
title: 7120163A
emoji: 📚
colorFrom: indigo
colorTo: yellow
sdk: gradio
sdk_version: 6.2.0
app_file: app.py
pinned: false
license: apache-2.0
short_description: Turtle and WaterPlant
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
